var foo = require('./lukeserver.js');
foo.startServer(8080);
foo.debugServer(true);